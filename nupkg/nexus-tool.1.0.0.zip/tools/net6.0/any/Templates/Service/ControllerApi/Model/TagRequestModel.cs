﻿namespace Nexus.CompanyAPI.Model;

[ExcludeFromCodeCoverage]
public class TagRequestModel
{
    required public string Name { get; set; }
}