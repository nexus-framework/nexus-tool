﻿// Global using directives

global using System.Diagnostics.CodeAnalysis;