﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Nexus.Company.Api.UnitTests")]
[assembly: InternalsVisibleTo("Nexus.Company.Api.IntegrationTests")]
